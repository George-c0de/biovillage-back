<?php

namespace Packages\Store\Http\Requests\StorePlace;

use App\Http\Requests\BaseApiRequest;

class IndexRequest extends BaseApiRequest
{

    public function rules()
    {
        return [];
    }
}
