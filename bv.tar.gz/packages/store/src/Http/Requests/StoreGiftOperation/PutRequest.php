<?php

namespace Packages\Store\Http\Requests\StoreGiftOperation;


class PutRequest extends StoreRequest
{
    public function rules()
    {
        return parent::rules();
    }
}
