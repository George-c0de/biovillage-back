Шаблон письма
@yield('content')
