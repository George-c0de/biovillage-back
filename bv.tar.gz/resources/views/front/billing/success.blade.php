@extends('front.layouts.main')

@section('content')

Оплата получена

@endsection