Запрос на изменение даты рождения:

Пользователь: {{ env('APP_URL') }}/admin/clients/{{ $clientId }}/
Дата рождения: {{ $birthday }}
