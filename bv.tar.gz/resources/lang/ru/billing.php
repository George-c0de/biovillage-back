<?php

return [
    'paymentDescription' => 'Оплата заказа №:orderId'
];