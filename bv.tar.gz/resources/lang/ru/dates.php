<?php

return [
    'dateFormat' => 'd.m.Y',
    'dateTimeFormat' => 'H:i',
    'fullDateTimeFormat' => 'd.m.Y H:i:s',
];
