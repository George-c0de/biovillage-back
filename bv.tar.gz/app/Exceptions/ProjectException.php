<?php

namespace App\Exceptions;

use Exception;

class ProjectException extends Exception
{
    // pass
}