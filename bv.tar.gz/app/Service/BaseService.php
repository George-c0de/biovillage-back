<?php

namespace App\Service;

/**
 * Базовый класс реализующий бизнес логику приложения
 * Class BaseService
 */
class BaseService {
    //
}