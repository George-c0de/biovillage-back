<?php

namespace App\Locale;

/**
 * Форматтер для РФ. Все правила форматирования описаны в базовом классе.
 */
class RussianFormatter extends BaseFormatter
{
}