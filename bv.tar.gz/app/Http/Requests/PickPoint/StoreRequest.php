<?php namespace App\Http\Requests\PickPoint;

use App\Http\Requests\BaseApiRequest;

class StoreRequest extends DefaultRequest
{

}
